$(document).ready(function(){
	$('#form-add-edit').validate();
});

$('#btn-import').click(function(){
    $('#form-import').submit();
});
