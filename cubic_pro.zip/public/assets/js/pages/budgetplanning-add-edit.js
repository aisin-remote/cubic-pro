$(document).ready(function(){
    $('#form-add-edit').validate();
});
