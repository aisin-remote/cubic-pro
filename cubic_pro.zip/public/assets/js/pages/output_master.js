$(document).ready(function(){
    $('.datepicker-year').datepicker({
        format: "yyyy",
        viewMode: "years", 
        minViewMode: "years",
        autoclose: true,
    });
});