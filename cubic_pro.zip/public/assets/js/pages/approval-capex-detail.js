var tData;
$(document).ready(function(){
  
  
});



