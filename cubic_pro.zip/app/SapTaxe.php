<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SapTaxe extends Model
{
    //
}
