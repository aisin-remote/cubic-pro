<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SapAsset extends Model
{
    public $incrementing = false;
}
