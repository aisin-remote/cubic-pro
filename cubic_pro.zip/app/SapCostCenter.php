<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SapCostCenter extends Model
{
    //
}
