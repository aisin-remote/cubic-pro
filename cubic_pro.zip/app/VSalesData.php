<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VSalesData extends Model
{
    protected $table = 'v_sales_datas';
}
