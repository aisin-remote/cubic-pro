<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VMaterialProduct extends Model
{
    protected $table = 'v_material_product';
}
